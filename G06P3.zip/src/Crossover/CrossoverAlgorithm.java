package Crossover;

import Models.Population;

public interface CrossoverAlgorithm {
	
	public void crossover(Population population, double crossOver);
}
